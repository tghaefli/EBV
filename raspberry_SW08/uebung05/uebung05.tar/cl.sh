#!/bin/bash

echo "compile $1"
arm-linux-gnueabihf-gcc -c -std=gnu99 -I../../Raspberry-Pi-SDK/oscar/include -DOSC_HOST -O2 $1.c

echo "link $1 to file app"
arm-linux-gnueabihf-gcc $1.o ../../Raspberry-Pi-SDK/oscar/library/libosc_target.a -o app
